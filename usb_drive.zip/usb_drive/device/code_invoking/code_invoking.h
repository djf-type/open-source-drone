#ifndef _code_invoking_
#define _code_invoking_
#include <mission_allocate.h>

#define USB_RX_buf_length 1024

extern u8      USB_RX_buf[USB_RX_buf_length];
extern u16     len;
void USB_VIRTURE_ACT(void);

#endif