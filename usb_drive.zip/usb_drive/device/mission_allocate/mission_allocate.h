#ifndef _mission_allocate_
#define _mission_allocate_

#include <stdio.h>
#include "sys.h"
#include "delay.h"
#include "usart.h" 
#include "usb_lib.h"
#include "hw_config.h"
#include "usb_pwr.h"	
#include <code_invoking.h>


#endif